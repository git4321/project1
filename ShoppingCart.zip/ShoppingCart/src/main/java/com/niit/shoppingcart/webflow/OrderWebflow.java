package com.niit.shoppingcart.webflow;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.OrderDAO;
import com.niit.shoppingcart.model.BillingAddress;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Order;
import com.niit.shoppingcart.model.PaymentMethod;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.ShippingAddress;
import com.niit.shoppingcart.model.User;

@Component
public class OrderWebflow {

	private static Logger log = LoggerFactory.getLogger(OrderWebflow.class);
	
	@Autowired
	private ShippingAddress shippingAddress;
	@Autowired
	private BillingAddress billingAddress;
	@Autowired
	private User user;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private CartDAO cartDAO;
	@Autowired
	private Cart cart;
	@Autowired
	private Order order;
	@Autowired
	private Product product;
	@Autowired
	private HttpSession httpSession;

	public Order initFlow() {

		log.debug("WEBFLOW Starting of the method initFlow");
		order = new Order();
		log.debug("WEBFLOW Ending of the method initFlow");
		return order;
	}

	public String addShippingAddress(Order order, ShippingAddress shippingAddress) {

		log.debug("WEBFLOW Starting of the method addShippingAddress");
		order.setShippingAddress("shippingAddress");
		log.debug("WEBFLOW Starting of the method addShippingAddress");
		return "success";
	}

	public String addBillingAddress(Order order, BillingAddress billingAddress) {

		log.debug("WEBFLOW Starting of the method addBillingAddress");
		order.setBillingAddress("billingAddress");
		log.debug("WEBFLOW Starting of the method addBillingAddress");
		return "success";
	}

	public String addPaymentMethod(Order order, PaymentMethod paymentMethod) {

		log.debug("WEBFLOW Starting of the method addPaymentMethod");
		order.setPaymentMethod("paymentMethod");
		confirmOrder(order);
		log.debug("WEBFLOW Starting of the method addPaymentMethod");
		return "success";
	}

	public String confirmOrder(Order order) {

		log.debug("WEBFLOW Starting of the method confirmOrder");
		orderDAO.saveOrUpdate(order);
		log.debug("WEBFLOW Starting of the method confirmOrder");
		return "success";
	}
}
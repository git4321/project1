package com.niit.shoppingcart.exception;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.hql.internal.ast.QuerySyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
public class ShoppingCartExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(ShoppingCartExceptionHandler.class);

	@ExceptionHandler(SQLException.class)
	public ModelAndView handleSQLException(HttpServletRequest request, Exception e) {
		logger.error("SQLException Occured:: URL=" + request.getRequestURI());
		logger.error("SQLException Occured:: Exception=" + e.getMessage());
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message",
				"It seems one of the table or few field does not exist in DB. See the logger for more information.");
		mv.addObject("errorMessage", e.getMessage());
		return mv;
	}

	@ExceptionHandler(CannotCreateTransactionException.class)
	public ModelAndView dbServerNotStarted(HttpServletRequest request, Exception e) {
		logger.error("SQLException Occured:: URL=" + request.getRequestURI());
		logger.error("SQLException Occured:: Exception=" + e.getMessage());
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", "It seems Database server not started.");
		mv.addObject("errorMessage", e.getMessage());
		return mv;
	}

	@ExceptionHandler(QuerySyntaxException.class)
	public String handleQuerySyntaxException(HttpServletRequest request, Exception e) {
		logger.error("SQLException Occured:: URL=" + request.getRequestURI());
		logger.error("SQLException Occured:: Exception=" + e.getMessage());
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", "It seems one of the query is not proper. See the logger for more information.");
		mv.addObject("errorMessage", e.getMessage());
		return "database_error";
	}

	@ExceptionHandler(NoHandlerFoundException.class)
	public ModelAndView noHandlerException(HttpServletRequest request, Exception e) {
		logger.error("SQLException Occured:: URL=" + request.getRequestURI());
		logger.error("SQLException Occured:: Exception=" + e.getMessage());
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", "Not handler found. Invaid URL see the logger for more information.");
		mv.addObject("errorMessage", e.getMessage());
		return mv;
	}

	@ExceptionHandler(IOException.class)
	public ModelAndView handleIOException(HttpServletRequest request, Exception e) {
		logger.error("SQLException Occured:: URL=" + request.getRequestURI());
		logger.error("SQLException Occured:: Exception=" + e.getMessage());
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", "Not able to contact to server. Please contact administration.");
		mv.addObject("errorMessage", e.getMessage());
		return mv;
	}

}

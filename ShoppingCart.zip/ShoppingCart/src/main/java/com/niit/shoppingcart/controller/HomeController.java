package com.niit.shoppingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/shoppingcart")
public class HomeController {
	@RequestMapping("/home")
	public String test() {
		return "home";
	}
	@RequestMapping("/register")
	public ModelAndView regis(Model model){
		
		
		ModelAndView  mv=new ModelAndView("home");
		mv.addObject("userClickedRegister", "true");
		
		return mv;
	}
	@RequestMapping("/category")
	public String cgory() {
		return "category";
	}
	@RequestMapping("/supplier")
	public String sup() {
		return "supplier";
	}
	@RequestMapping("/product")
	public String pro() {
		return "product";
	}
	@RequestMapping("/login")
	public String log() {
		return "login";
	}
}

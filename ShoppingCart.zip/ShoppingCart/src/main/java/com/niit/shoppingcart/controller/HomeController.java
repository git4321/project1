package com.niit.shoppingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/shoppingcart")
public class HomeController {
	@RequestMapping("/home")
	public String test() {
		return "home";
	}

	@RequestMapping("/register")
	public ModelAndView regis(Model model) {

		ModelAndView mv = new ModelAndView("home");
		mv.addObject("userClickedRegister", "true");

		return mv;
	}

	@RequestMapping("/category")
	public ModelAndView cate(Model model) {

		ModelAndView mv1 = new ModelAndView("home");
		mv1.addObject("userClickCategory", "true");
		return mv1;
	}
	

	@RequestMapping("/supplier")
	public ModelAndView sup(Model model) {

		ModelAndView mv2 = new ModelAndView("home");
		mv2.addObject("userClickSupplier", "true");
		return mv2;
	}

	@RequestMapping("/product")
	public ModelAndView pro(Model model) {

		ModelAndView mv3 = new ModelAndView("home");
		mv3.addObject("userClickProduct", "true");
		return mv3;
	}

	@RequestMapping("/login")
	public ModelAndView log(Model model) {

		ModelAndView mv4 = new ModelAndView("home");
		mv4.addObject("userClickLogin", "true");
		return mv4;
	}
}

package com.niit.shoppingcart.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

public class FileUtil {
	private static Logger log = LoggerFactory.getLogger(FileUtil.class);

	public static void upload(String path, MultipartFile file, String FileName) {
		log.debug("Starting of the method upload");
		log.debug("path: ", +path);
		log.debug("fileName: ", fileName);
		if (!file.isEmpty()) {
			try {
				byte[] bytesv = file.getBytes();
				// Creating the directory to store file
				File dir = new File(path);
				if (!dir.exists())
					dir.mkdirs();// make/create directory
				// create the file on the server
				File serverFile = new file(dir.getAbsolutePath() + File.separator + fileName);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytesv);
				stream.close();
				log.info("Server File Location=", +serverFile.getAbsolutePath());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		log.debug("Ending of the method upload");
	}
}

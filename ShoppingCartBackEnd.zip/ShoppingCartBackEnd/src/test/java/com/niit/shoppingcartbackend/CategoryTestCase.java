/*package com.niit.shoppingcartbackend;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

import junit.framework.Assert;

public class CategoryTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static Category category;
	@Autowired
	static CategoryDAO categoryDAO;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		category = (Category) context.getBean("category");
		System.out.println("The Objects are created");
	}

	// Start writing Junit Cases
	// For each method defined in DAO

	//@Test
	public void getAllCategotyTestCase() {
		Assert.assertEquals("Get All Category test Case", 5, categoryDAO.list().size());

	}

	//@Test
	public void createCategoryTestCase() {
		category.setId("CT_5");
		category.setName("dell");
		category.setDescription("This is laptop category");
		boolean status = categoryDAO.save(category);
		Assert.assertEquals("Create Category Test Case", true, status);
	}

	//@Test
	public void deleteCategoryTestCase() {
		category.setId("CT_6");
		boolean status = categoryDAO.delete(category);
		Assert.assertEquals("Delete Category Test Case", true, status);

	}

	//@Test
	public void updateCategoryTestCase() {
		category.setId("CT_4");
		category.setName("thinkpad");
		boolean status = categoryDAO.update(category);
		Assert.assertEquals("Update Category TestCase", true, status);
	}

	//@Test
	public void getCategoryTestCase() {
		Assert.assertEquals("Get Category Test Case", null, categoryDAO.get("CT_29"));
	}
	//@Test
	public void getTestCase(){
		Assert.assertEquals("Get Test Case", 2, categoryDAO.get("CT_1").getProduct().size());
	}
	

}
*/
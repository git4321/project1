/*package com.niit.shoppingcartbackend;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;

import junit.framework.Assert;

public class UserTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static User user;
	@Autowired
	static UserDAO userDAO;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		userDAO = (UserDAO) context.getBean("userDAO");
		user = (User) context.getBean("user");
		System.out.println("The Objects are created");
	}

	// Start writing Junit Cases
	// For each method defined in DAO
	//@Test
	public void getAllUserTestCase() {
		Assert.assertEquals("Get All Category test Case", 4, userDAO.list().size());
	}

	//@Test
	public void createUserTestCase() {
		user.setId("SU_4");
		user.setName("BigC");
		user.setMail("Hydrabad");
		boolean status = userDAO.save(user);
		Assert.assertEquals("Create User Test Case", true, status);
	}

	//@Test
	public void deleteUserTestCase() {
		user.setId("SU_5");
		boolean status = userDAO.delete(user);
		Assert.assertEquals("Delete User Test Case", true, status);

	}

	//@Test
	public void updateUserTestCase() {
		user.setId("SU_2");
		user.setName("BigC");
		boolean status = userDAO.update(user);
		Assert.assertEquals("Update User Test Case", true, status);
		;
	}

	//@Test
	public void getUserTestCase() {
		Assert.assertEquals("Get User Test Case", null, userDAO.get("abcd"));
	}

}
*/
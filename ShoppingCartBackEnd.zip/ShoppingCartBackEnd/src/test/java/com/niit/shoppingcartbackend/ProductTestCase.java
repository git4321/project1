/*package com.niit.shoppingcartbackend;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;

import junit.framework.Assert;

public class ProductTestCase {
	
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static Product product;
	@Autowired
	static ProductDAO productDAO;
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		productDAO = (ProductDAO) context.getBean("productDAO");
		product = (Product) context.getBean("product");
		System.out.println("The Objects are created");
	}
	// Start writing Junit Cases
		// For each method defined in DAO

	///@Test
	public void getAllProductTestCase() {
		Assert.assertEquals("Get All Product test Case", 4, productDAO.list().size());
	}
//	@Test
	public void createProductTestCase() {
		product.setId("PU_4");
		product.setName("Book");
		product.setPrice(200);
		product.setCategory_id("CT_3");
		product.setSupplier_id("SU_2");
		boolean status = productDAO.save(product);
		Assert.assertEquals("Create Product Test Case", true, status);
	}
	//@Test
	public void deleteProductTestCase() {
		product.setId("PU_1");
		boolean status = productDAO.delete(product);
		Assert.assertEquals("Delete Product Test Case", true, status);

	}
	//@Test
	public void updateProductTestCase() {
		product.setId("PU_2");
		product.setName("Laptop");
		product.setPrice(20000);
		boolean status = productDAO.update(product);
		Assert.assertEquals("Update Product Test Case", true, status);
		;
	}
	//@Test
	public void getProductTestCase() {
		Assert.assertEquals("Get Product Test Case", "samsung", productDAO.get("PR1").getCategory().getName());
	}
	
}
*/
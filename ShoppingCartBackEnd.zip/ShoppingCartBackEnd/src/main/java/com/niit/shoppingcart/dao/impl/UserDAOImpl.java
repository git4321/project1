package com.niit.shoppingcart.dao.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserDAOImpl implements UserDAO {

	@Autowired
	SessionFactory sessionFactory;

	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public boolean save(User user) {
		try {
			if (get(user.getId()) != null) {
				return false;
			}
			Session session = sessionFactory.openSession();
			session.save(user);
			session.flush();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}

	}

	@Transactional
	public boolean update(User user) {
		try {
			if (get(user.getId()) == null) {
				return false;
			}
			Session session = sessionFactory.openSession();
			session.update(user);
			session.flush();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}

	}

	@Transactional
	public boolean delete(User user) {
		try {
			if (get(user.getId()) == null) {
				return false;
			}
			Session session = sessionFactory.openSession();
			session.delete(user);
			session.flush();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}

	}

	@Transactional
	public User get(String id) {
		return (User) sessionFactory.openSession().get(User.class, id);
	}

	@Transactional
	public List<User> list() {
		// select*from category
		String hql = "from User";// We need to convert this hql to db
		// specific query
		Query query = sessionFactory.openSession().createQuery(hql);
		return query.list();
	}

}

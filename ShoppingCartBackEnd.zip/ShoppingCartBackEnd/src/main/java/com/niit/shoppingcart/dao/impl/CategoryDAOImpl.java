package com.niit.shoppingcart.dao.impl;

import java.util.List;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

public class CategoryDAOImpl implements CategoryDAO {

	@Override
	public boolean save(Category category) {

		return false;
	}

	@Override
	public boolean update(Category category) {

		return false;
	}

	@Override
	public boolean delete(Category category) {

		return false;
	}

	@Override
	public Category get(String id) {

		return null;
	}

	@Override
	public List<Category> list() {

		return null;
	}

}

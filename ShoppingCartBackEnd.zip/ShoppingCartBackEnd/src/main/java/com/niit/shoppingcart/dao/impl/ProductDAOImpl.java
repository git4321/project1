package com.niit.shoppingcart.dao.impl;

import java.util.List;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public boolean save(Product product) {

		return false;
	}

	@Override
	public boolean update(Product product) {

		return false;
	}

	@Override
	public boolean delete(Product product) {

		return false;
	}

	@Override
	public Product get(String id) {

		return null;
	}

	@Override
	public List<Product> list() {

		return null;
	}

}

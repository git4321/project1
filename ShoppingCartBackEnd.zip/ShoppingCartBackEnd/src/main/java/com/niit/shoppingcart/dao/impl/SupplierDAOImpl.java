package com.niit.shoppingcart.dao.impl;

import java.util.List;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class SupplierDAOImpl implements SupplierDAO {

	@Override
	public boolean save(Supplier supplier) {

		return false;
	}

	@Override
	public boolean update(Supplier supplier) {

		return false;
	}

	@Override
	public boolean delete(Supplier supplier) {

		return false;
	}

	@Override
	public Supplier get(String id) {

		return null;
	}

	@Override
	public List<Supplier> list() {

		return null;
	}

}
